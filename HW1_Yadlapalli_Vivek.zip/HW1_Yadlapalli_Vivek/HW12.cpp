//
//  main2.cpp
//  HW1_Yadlapalli_Vivek
//
//  Created by ymmkrishna on 05/09/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include <iostream>
using namespace std;

int main() {
    
    float a,b,c,d,e,f;
    
    a = sizeof(char);
    cout << "byte size of char is "<<a<<"\n";
    
    b = sizeof(short);
    cout << "byte size of short int is "<<b<<"\n";
    
    c = sizeof(int);
    cout << "byte size of int is "<<c<<"\n";
    
    d = sizeof(long);
    cout << "byte size of long int is "<<d<<"\n";
    
    e = sizeof(float);
    cout << "byte size of float is "<<e<<"\n";
    
    f = sizeof(double);
    cout << "byte size of double is "<<f<<"\n";
    
    
}



