//
//  main.cpp
//  HW9
//
//  Created by ymmkrishna on 13/11/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include <iostream>
#include <math.h>
#include <fstream>

using namespace std;

void swap(float *a,float *b)
{
    float temp;
    temp=*a;
    *a=*b;
    *b=temp;
}

void sort(float a[],int n)
{
    for(int k=0;k<n;k++)
    {
        for(int j=k+1;j<n;j++)
        {
            if(a[k]>a[k])
            {
                float temp1=a[k];float temp2=a[j];
                swap(&temp1,&temp2);
                a[k]=temp1;a[j]=temp2;
            }
        }
    }
}

class Point{
        float x;float y;
    public:
        Point()= default;
        Point(float a,float b);
    void set_x_y(float a, float b){
        x=a;
        y=b;
    }
    float get_x() {
        return x;
    }
    float get_y() {
        return y;
    }
    float distance_to_origin(){
        return sqrt(x*x+y*y);
    }
    float distance_to_point(const Point&p){
        return sqrt(((p.x)-x)*((p.x)-x)+((p.y)-y)*((p.y)-y));
    }
friend ostream& operator<< (ostream &os,const Point&p);
};

Point::Point(float a, float b){
    x=a;
    y=b;
}

ostream& operator<< (ostream &os,const Point&p){
    os<<"("<<p.x<<","<<p.y<<")"<<endl;
    return os;
}

class TimeSeries{
        float* pSeries = new float[100];
        int seriesLen;
    public:
        TimeSeries()= default;
        TimeSeries(const double* p, int n);
    void setSeries(const double* p, int n){
        seriesLen = n;
        for(int i=0;i<n;i++){
            pSeries[i] = p[i];
        }
    };
    int getSeriesLen(){
        return seriesLen;
    }
    const float* getSeries(){
        return pSeries;
    }
    void generateReturns(float *returns)
    {
        for(int k=0;k<seriesLen;k++)
        {
            *(returns+k)=(*(pSeries+k+1)-*(pSeries+k))/(*(pSeries+k));
        }
    }
    void findMaxMin(float& max,float &min,int& maxIndx,int& minIndx)
    {
        float a[seriesLen];
        for(int k=0;k<seriesLen;k++)
        {
            a[k]=*(pSeries+k);
        }
        sort(a,seriesLen);
        max=a[seriesLen-1];
        min=a[0];
        for(int k=0;k<seriesLen;k++)
        {
            if(*(pSeries+k)==a[0])
                minIndx=k;
            else if(*(pSeries+k)==a[seriesLen-1])
                maxIndx=k;
        }
    }
    void calcAvgReturnVol(float const *returns,float& avgRet,float & retStd){
        float mean=0,xsq=0,sdev=0;
        for(int k=0;k<seriesLen;k++)
        {
            mean=mean+*(returns+k);
            xsq=xsq+((*(returns+k))*(*(returns+k)));
        }
        mean=mean/seriesLen;
        sdev=(xsq/seriesLen)-(mean*mean);
        avgRet=mean*252;
        retStd=mean*sqrt(252);
    }
    
};

int main() {
    bool check=true,check2=true;
    ofstream outfile("Output Data");
    float a,b;
    char str;
    Point A;
    Point* arr = new Point[5];
while(check){
        check2=true;
        cout << "input coordinate x of A : "<<endl;
        cin>>a;
        cout << "input coordinate y of A: "<<endl;
        cin>>b;
        A.set_x_y(a, b);
        cout<<"The distance of A to origin is : "<<A.distance_to_origin()<<endl;
        cout << "input 1st array coordinate x: "<<endl;
        cin>>a;
        cout << "input 1st array coordinate y: "<<endl;
        cin>>b;
        arr[0].set_x_y(a,b);
        cout << "input 2nd array coordinate x: "<<endl;
        cin>>a;
        cout << "input 2nd array coordinate y: "<<endl;
        cin>>b;
        arr[1].set_x_y(a,b);
        cout << "input 3rd array coordinate x: "<<endl;
        cin>>a;
        cout << "input 3rd array coordinate y: "<<endl;
        cin>>b;
        arr[2].set_x_y(a,b);
        cout << "input 4th array coordinate x: "<<endl;
        cin>>a;
        cout << "input 4th array coordinate y: "<<endl;
        cin>>b;
        arr[3].set_x_y(a,b);
        cout << "input 5th array coordinate x: "<<endl;
        cin>>a;
        cout << "input 5th array coordinate y: "<<endl;
        cin>>b;
        arr[4].set_x_y(a,b);
        
        outfile<<"The distance from "<<arr[0]<<" to "<<A<< "is : "<<arr[0].distance_to_point(A)<<endl;
        outfile<<"The distance from "<<arr[1]<<" to "<<A<< "is : "<<arr[1].distance_to_point(A)<<endl;
        outfile<<"The distance from "<<arr[2]<<" to "<<A<< "is : "<<arr[2].distance_to_point(A)<<endl;
        outfile<<"The distance from "<<arr[3]<<" to "<<A<< "is : "<<arr[3].distance_to_point(A)<<endl;
        outfile<<"The distance from "<<arr[4]<<" to "<<A<< "is : "<<arr[4].distance_to_point(A)<<endl;
        
    while(check2){
        cout<<"Press y to rerun, n to stop"<<endl;
        cin>>str;
        if(str == 'y'){
            check2=false;
        }else if (str=='n'){
            check2=false;
            check=false;
        }else{
            cout<<"Invalid input, try again"<<endl;

                }
    }
}
    return 0;
}
