//
//  Funcs.hpp
//  HW8
//
//  Created by ymmkrishna on 06/11/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#ifndef Funcs_hpp
#define Funcs_hpp

#include <stdio.h>

using namespace std;

double function_1(double x);
double function_2(double x);
double function_3(double x);
double function_1_Derivative(double x);
double function_2_Derivative(double x);
double function_3_Derivative(double x);
double Newton_Raphson(double (*func)(double x), double (*deriv)(double x), double x, double tolerance);
double function_4(double x, double y);
double function_5(double x, double y);
double D_XX(double (*func)(double x, double y), double x, double y, double d);
double D_YY(double (*func)(double x, double y), double x, double y, double d);

double D_XY(double (*func)(double x, double y), double x, double y, double d);

double Hessian(double (*func)(double x, double y), double x, double y, double d);
#endif /* Funcs_hpp */
