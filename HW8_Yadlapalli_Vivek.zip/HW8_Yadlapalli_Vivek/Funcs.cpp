//
//  Funcs.cpp
//  HW8
//
//  Created by ymmkrishna on 06/11/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//
#include <iostream>
#include <math.h>
#include "Funcs.hpp"

using namespace std;

double function_1(double x){
    return exp(x) - (x*x);
}

double function_1_Derivative(double x){
    return exp(x) - (2*x);
}

double function_2(double x){
    return (-2*x) - (log(x));
}

double function_2_Derivative(double x){
    return -2-(1/x);
}

double function_3(double x){
    return x+(cos(x))*(cos(x));
}

double function_3_Derivative(double x){
    return 1-2*cos(x)*sin(x);
}

double Newton_Raphson(double (*func)(double x), double (*deriv)(double x), double x, double tol){

    double temp = x-(func(x)/deriv(x));
    if (abs(temp-x) > tol)
        return Newton_Raphson(func, deriv, temp, tol);
    else
        return temp;
}

double function_4(double x, double y){
    return (x*x) + (y*y) + 6*(x*x*y*y);
}

double function_5(double x, double y){
    return x*y*(x-y);
}

double D_XX(double (*func)(double x, double y), double x, double y, double d){
    return (func(x+d,y) + func(x-d,y) - 2*func(x,y))/(d*d);
}

double D_YY(double (*func)(double x, double y), double x, double y, double d){
    return (func(x,y+d) + func(x,y-d)-2*func(x,y))/(d*d);
}

double D_XY(double (*func)(double x, double y), double x, double y, double d){

    return (func(x+d,y+d) + func(x-d,y-d)-func(x+d,y-d) - func(x-d,y+d))/(4*d*d);
}

double Hessian(double (*func)(double x, double y), double x, double y, double d){
    cout << " X deriv is " << D_XX(func,x,y,d) << "\n Y deriv is " << D_YY(func,x,y,d) << "\n XY deriv is " << D_XY(func,x,y,d) << endl;
    return D_XX(func,x,y,d) * D_YY(func,x,y,d) - (D_XY(func,x,y,d) * D_XY(func,x,y,d));
}
