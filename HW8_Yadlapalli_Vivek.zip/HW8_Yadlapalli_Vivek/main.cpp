//
//  main.cpp
//  HW8
//
//  Created by ymmkrishna on 06/11/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include <iostream>
#include <math.h>
#include "Funcs.hpp"

using namespace std;


int main(){

    double tol = 0.001;
    double x = 1;

    cout << "\n Root of Function 1 is " << Newton_Raphson(&function_1, &function_1_Derivative, x, tol);

    cout << "\n Root of Function 2 is " << Newton_Raphson(&function_2, &function_2_Derivative, x, tol);

    cout << "\n Root of Function 3 is " << Newton_Raphson(&function_3, &function_3_Derivative, x, tol);

    cout << endl;

    cout << "\n \n Hessian of Function 1 at 0,0 is \n" << Hessian(&function_4, 0, 0, 0.0001);

    cout << "\n \n Hessian of Function 1 at 1,1 is \n" << Hessian(&function_4, 1, 1, 0.0001);

    cout << "\n \n Hessian of Function 2 at 0,0 is \n" << Hessian(&function_5, 0, 0, 0.0001);

    cout << "\n \n Hessian of Function 2 at 1,1 is \n" << Hessian(&function_5, 1, 1, 0.0001);
    
    cout << endl;



}
