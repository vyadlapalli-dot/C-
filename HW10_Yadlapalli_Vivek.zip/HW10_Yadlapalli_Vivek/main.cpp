//
//  main.cpp
//  HW_10
//
//  Created by ymmkrishna on 23/11/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include <iostream>
#include <math.h>
#include <fstream>

using namespace std;



class Point{
        float x;float y;
    public:
        Point()= default;
        Point(float a,float b);
    void set_x_y(float a, float b){
        x=a;
        y=b;
    }
    float get_x() {
        return x;
    }
    float get_y() {
        return y;
    }
    float length(){
        return sqrt(x*x+y*y);
    }
    friend ostream& operator<< (ostream &os,const Point&p);
    friend Point operator- (const Point &p);
    friend Point operator+(const Point &p1, const Point &p2);
    friend Point operator-(const Point &p1, const Point &p2);
    friend void operator+=(Point &p1, const Point &p2);
    friend istream& operator>>(istream &in, Point &p);
    friend float operator/( Point &p1,  Point &p2);
    friend bool operator>( Point &p1,  Point &p2);
    friend bool operator<( Point &p1,  Point &p2);
};

Point::Point(float a, float b){
    x=a;
    y=b;
}

ostream& operator<< (ostream &os,const Point&p){
    os<<"("<<p.x<<","<<p.y<<")";
    return os;
}

istream& operator>> (istream &in, Point &p){
    in >> p.x;
    in >> p.y;
    return in;
}

Point operator- (Point const &p){
    return Point(-p.x, -p.y);
}

Point operator+ (Point const &p1,const Point &p2){
    return Point(p1.x+p2.x,p1.y+p2.y);
}
Point operator- (Point const &p1,const Point &p2){
    return Point(p1.x-p2.x,p1.y-p2.y);
}
float operator/ (Point &p1, Point &p2){
    return p1.length() / p2.length();
}
bool operator> (Point &p1, Point &p2){
    return p1.length() > p2.length();
}
bool operator< (Point &p1, Point &p2){
    return p1.length() < p2.length();
}

//(1,2) += (2,3)
void operator+= (Point &p1, const Point &p2){
    p1.x += p2.x;
    p1.y += p2.y;
}
double dot(Point &p1, Point &p2){
    return p1.get_x() * p2.get_x() + p1.get_y() * p2.get_y();
}


void swap(Point *a,Point *b)
{
    Point temp;
    temp=*a;
    *a=*b;
    *b=temp;
}

void sort(Point a[],int n, bool asc)
{
    for(int k=0;k<n;k++)
    {
        for(int j=k+1;j<n;j++)
        {
            if(asc){
                if(a[j]<a[k] )
                {
                    Point temp1=a[k];Point temp2=a[j];
                    swap(&temp1,&temp2);
                    a[k]=temp1;a[j]=temp2;
                }
                
            }
            else{
                if(a[j]>a[k] )
                {
                    Point temp1=a[k];Point temp2=a[j];
                    swap(&temp1,&temp2);
                    a[k]=temp1;a[j]=temp2;
                }
            }
        }
    }
}

int findClosestIndex(Point a[], int n, Point b){
    int i, min_index = 0, dist;
    float min = (a[0] - b).length();
    
    for(i=0; i < n; i++){
        dist = (a[i] - b).length();
        if(min > dist){
            min_index = i;
            min = dist;
        }
    }
    return min_index;
}

int nLines(const char *filename){
    ifstream inFile;
    inFile.open(filename);
    string temp;
    int n=0;
    if(!inFile){
        cout << "couldn't open " << filename << "file!";
        exit(1);
    }
    while (getline(inFile,temp)) {
        n++;
    }
    inFile.close();
    return n;
}

class Stock{
    double *Prices=nullptr;
    int nPrices=0;
    double *Returns=nullptr;
    double avgReturn;
    double returnVol;
public:
    Stock();
    Stock(const double* p, int n);
    Stock(const Stock &obj);
};

Stock::Stock(){
    cout << "default constrcutor called" << endl;
}
Stock::Stock(const double* p, int n){
    cout << "Constructor with filename called" << endl;
    nPrices = n;
    Prices = new double[nPrices];
    Returns = new double[nPrices];
    avgReturn = 0;
    int i;
    double temp;
    
    for (i = 0; i < nPrices; i++) {
        Prices[i] = p[i];
        if(i == 0){
            Returns[i] = 0;
        }
        else{
            Returns[i] = 1 - Prices[i-1] / Prices[i];
        }
        avgReturn += Returns[i];
        i++;
    }
    avgReturn /= nPrices;
    for(i = 1; i < nPrices; i++){
        temp = Returns[i] - avgReturn;
        returnVol += temp*temp;
    }
    returnVol /= nPrices - 2;
    returnVol = sqrt(returnVol);
}
Stock::Stock(const Stock &obj){
    cout << "Copy constructor called" << endl;
    avgReturn = obj.avgReturn;
    nPrices = obj.nPrices;
    returnVol = obj.returnVol;
    Prices = obj.Prices;
    Returns = obj.Returns;
}

int main() {
    char str;
    Point P1, P2, P3;
    cout << "Enter P1:";
    cin>>P1;
    cout << "Enter P2:";
    cin>>P2;

    cout<<-P1<<"and"<<-P2<<endl;
    cout<<P1 + P2 << endl;
    cout<< P1 - P2 << endl;
    cout << P1/P2 << endl;
    cout << dot(P1,P2) << endl;
    cout << (P1 > P2) << endl;
    cout << (P1 < P2) << endl;
    cout << (P1 - P2).length() << endl;
    ifstream inFile ;
    inFile.open("xy_data.txt");
    if(!inFile){
        cout << "couldn't open xy_data.txt file!";
        exit(1);
    }
    Point t;
    Point* arr = new Point[10];
    int i = 0;
    while(inFile >> t){
        arr[i] = t;
        cout << arr[i] << ",";
        i++;
    }
    cout << endl;
    inFile.close();
    cout << "Press a for ascending sort, d for descending sort:";
    cin >> str;
    sort(arr, 10, str == 'a');
    for(i = 0; i < 10; i++){
        cout << arr[i] << ",";
    }
    cout << endl;
    
    cout << "Enter another point (P3): ";
    cin >> P3;
    int ind = findClosestIndex(arr, 10, P3);
    cout << "Closet point is " << arr[ind] << " which is " << (arr[ind] - P3).length() << " away";
    
    
//    bool check=true,check2=true;
//    ofstream outfile("Output Data");
//    float a,b;
    
//    Point A;
//    Point* arr = new Point[5];
//
//while(check){
//        check2=true;
//        cout << "input coordinate x of A : "<<endl;
//        cin>>a;
//        cout << "input coordinate y of A: "<<endl;
//        cin>>b;
//        A.set_x_y(a, b);
//        cout<<"The distance of A to origin is : "<<A.length()<<endl;
//        cout << "input 1st array coordinate x: "<<endl;
//        cin>>a;
//        cout << "input 1st array coordinate y: "<<endl;
//        cin>>b;
//        arr[0].set_x_y(a,b);
//        cout << "input 2nd array coordinate x: "<<endl;
//        cin>>a;
//        cout << "input 2nd array coordinate y: "<<endl;
//        cin>>b;
//        arr[1].set_x_y(a,b);
////        cout << "input 3rd array coordinate x: "<<endl;
////        cin>>a;
////        cout << "input 3rd array coordinate y: "<<endl;
////        cin>>b;
////        arr[2].set_x_y(a,b);
////        cout << "input 4th array coordinate x: "<<endl;
////        cin>>a;
////        cout << "input 4th array coordinate y: "<<endl;
////        cin>>b;
////        arr[3].set_x_y(a,b);
////        cout << "input 5th array coordinate x: "<<endl;
////        cin>>a;
////        cout << "input 5th array coordinate y: "<<endl;
////        cin>>b;
////        arr[4].set_x_y(a,b);
//
//    cout << (-arr[0]);
//    arr[0] += arr[1];
//    cout << (arr[0]);
//
//    while(check2){
//        cout<<"Press y to rerun, n to stop"<<endl;
//        cin>>str;
//        if(str == 'y'){
//            check2=false;
//        }else if (str=='n'){
//            check2=false;
//            check=false;
//        }else{
//            cout<<"Invalid input, try again"<<endl;
//
//                }
//    }
//}
    return 0;
}
