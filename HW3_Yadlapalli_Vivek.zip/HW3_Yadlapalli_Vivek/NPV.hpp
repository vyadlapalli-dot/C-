//
//  NPV.hpp
//  HW3
//
//  Created by ymmkrishna on 18/09/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#ifndef NPV_hpp
#define NPV_hpp

#include <stdio.h>
#include <math.h>

float riskfree_NPV(float N,float T, float R);               //Declaring of the risk free NPV function
float risky_NPV(float N,float T,float R,float alpha);       //Declaring of the risky NPV fuunction

#endif /* NPV_hpp */
