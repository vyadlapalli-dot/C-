//
//  main.cpp
//  HW3
//
//  Created by ymmkrishna on 18/09/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include <iostream>
#include <math.h>
#include "NPV.hpp"

using namespace std;

//Global Variable
float gRiskfreeRate = 0;

int main() {
    
    gRiskfreeRate = 0.035;  //Direct Assignment
    float rfn = riskfree_NPV(1000, 1.5, gRiskfreeRate);   //Defining variables to output
    float rn = risky_NPV(1000, 1.0, gRiskfreeRate, 0.15);  //Defining variables to output
    
    cout << "Risk Free NPV of cash payment $1000 in 1.5 year of time is     $" <<rfn<<"\n\n"<<endl;
    
    cout << "Risky NPV of cash payment $1000 from a CCC rated company in \n1 year of time with alpha 0.15 is                              $" <<rn<<"\n\n"<<endl;
    
    return 0;
}
