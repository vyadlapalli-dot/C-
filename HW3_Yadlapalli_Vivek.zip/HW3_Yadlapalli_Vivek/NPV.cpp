//
//  NPV.cpp
//  HW3
//
//  Created by ymmkrishna on 18/09/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include "NPV.hpp"

float riskfree_NPV(float N,float T, float R){               //Defining the 1st Function
    return N/pow(1+R,T);
}

float risky_NPV(float N,float T,float R,float alpha){       //Defining the 2nd Function
    return N/pow(1+R+alpha,T);
}
