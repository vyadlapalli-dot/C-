//
//  funcs.cpp
//  HW_7
//
//  Created by ymmkrishna on 23/10/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include "funcs.hpp"
using namespace std;


double* MatVecMult(double **mat,int n1, int n2, double const *vec, int k){
    if(n2==k){
        double *result = new double[n1];
        for (int i=0;i<n2;i++){
             result[i]=0;
        }

        for (int i=0;i<n1;i++){
            for (int j=0;j<n2;j++){
                result[i]+=( mat[i][j]*vec[j]);
            }
        }
        return result;
        
    }else return nullptr;
}

void getCofactor(double **mat, double **temp, int p, int q, int n)
{
    int i = 0, j = 0;
  
    for (int row = 0; row < n; row++)
    {
        for (int col = 0; col < n; col++)
        {
            
            if (row != p && col != q)
            {
                temp[i][j++] = mat[row][col];
  
                if (j == n - 1)
                {
                    j = 0;
                    i++;
                }
            }
        }
    }
}

double det(double **mat, int n)
{
    int D = 0;
    
    if (n == 1)
        return mat[0][0];
  
    double **temp = new double*[n];
    
    for (int i=0;i<n;i++) {
        temp[i]=new double[n];
    }
  
    double sign = 1;
  
    for (int f = 0; f < n; f++)
    {
        getCofactor(mat, temp, 0, f, n);
        D += sign * mat[0][f] * det(temp, n - 1);
  
        sign = -sign;
    }
  
    return D;
}

bool MatrixMult(double **mat1,double **mat2, int row1, int col1, int row2, int col2,double **prod)
{   if(col1==row2){
        int i, j, k;
        for (i = 0; i < row1; i++)
        {
            for (j = 0; j < col2; j++)
            {
                prod[i][j] = 0;
                for (k = 0; k < col1; k++)
                    prod[i][j] += mat1[i][k] *mat2[k][j];
            }
        }
        return true;
    }else
        return false;
}
