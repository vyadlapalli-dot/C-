//
//  funcs.hpp
//  HW_7
//
//  Created by ymmkrishna on 23/10/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#ifndef funcs_hpp
#define funcs_hpp

#include <stdio.h>

using namespace std;

double* MatVecMult(double **mat,int n1, int n2, double const *vec, int k);
void getCofactor(double **mat, double **temp, int p, int q, int n);
double det(double **mat, int n);
bool MatrixMult(double **mat1,double **mat2, int row1, int col1, int row2, int col2,double **prod);

#endif /* funcs_hpp */
