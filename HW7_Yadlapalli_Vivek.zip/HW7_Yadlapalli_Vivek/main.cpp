//
//  main.cpp
//  HW_7
//
//  Created by ymmkrishna on 23/10/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include <iostream>
#include <fstream>
#include "funcs.hpp"
using namespace std;
  

int main() {
    
    double mat[2][3] = {{-1,4.5,6.2},{2,-3.4,-2}};
    double **m = new double*[2];
    for (int i=0;i<2;i++) {
        m[i]=new double[3];
    }
    for(int i = 0;i<2;i++)
        for(int j=0;j<3;j++)
            m[i][j]=mat[i][j];
    
    double v1[2] =  {7,-1.2};
    double v2[3] = {1,2,1.5};
    
    double *n = new double[2];
    
    ofstream outfile("Output Data");
    outfile<<"ANSWER A"<<endl;
    outfile<< "--------" << endl;
    
    if (MatVecMult(m,2,3,v1,2))
        outfile<<"Test 1 Result: "<<*MatVecMult(m,2,3,v1,2)<<endl;
    else
        outfile<<"Test 1 Result: "<<"null pointer"<<endl;
    if (*MatVecMult(m,2,3,v2,3)){
        *n=*MatVecMult(m,2,3,v2,3);
        *(n+1)=*(MatVecMult(m,2,3,v2,3)+1);
        outfile<<"Test 2 Result: ";
        for(int i = 0;i<2;i++){
            if(i==0)
                outfile<<"( "<<n[i]<<", ";
            if(i==1)
                outfile<<n[i]<<" )"<<endl;
        }
    }else
        outfile<<"Test 2 Result: "<<"null pointer"<<endl;
    
    double mat_2[3][3] = {{2,-3,1},{2,0,-1},{1,4,5}};
    double **m_2 = new double*[3];
    for (int i=0;i<3;i++) {
        m_2[i]=new double[3];
    }
    for(int i = 0;i<3;i++)
        for(int j=0;j<3;j++)
            m_2[i][j]=mat_2[i][j];
    
    outfile<<"ANSWER B"<<endl;
    outfile<< "--------" << endl;
    
    outfile<<"Determinant of given matrix is "<<det(m_2,3)<<endl;
    
    double **prod = new double*[2];
    for (int i=0;i<2;i++) {
        prod[i]=new double[3];
    }
    
    outfile<<"ANSWER C"<<endl;
    outfile<< "--------" << endl;
    
    if(MatrixMult(m_2, m, 3, 3, 2, 3, prod)){
        outfile<<"Test 1 Result: "<<endl;
        for(int i = 0;i<2;i++)
            for(int j=0;j<3;j++){
                outfile<<prod[i][j]<<" ";
                if(j==2)outfile<<endl;
            }
    }else
        outfile<<"Test 1 Result: Product does not exist"<<endl;
    if(MatrixMult(m, m_2, 2, 3, 3, 3, prod)){
        outfile<<"Test 2 Result: "<<endl;
        for(int i = 0;i<2;i++)
            for(int j=0;j<3;j++){
                outfile<<prod[i][j]<<" ";
                if(j==2)outfile<<endl;
            }
    }else
        outfile<<"Test 2 Result: Product does not exist"<<endl;
    return 0;
}
