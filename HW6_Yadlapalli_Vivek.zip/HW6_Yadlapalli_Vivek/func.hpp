//
//  func.hpp
//  HW6
//
//  Created by ymmkrishna on 09/10/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#ifndef func_hpp
#define func_hpp

#include<stdio.h>
#include<iostream>
#include<math.h>
#include<fstream>
#include<string>
#include<iomanip>

void MaxMin(double const *arr,const int& n,double& max,double &min,int& maxIndx,int& minIndx);
void swap(double *a,double *b);
void sort(double a[],int n);
void MaxMin(int const *arr,const int& n,int& max,int &min,int& maxIndx,int& minIndx);
void swap(int *a,int *b);
void sort(int a[],int n);
void generateReturns(double const *prices, const int& n, double *returns);
void AnnualizedStats (double const *returns, const int& n,const char& seriesType,double& avgRet,double & retStd);

#endif /* func_hpp */
