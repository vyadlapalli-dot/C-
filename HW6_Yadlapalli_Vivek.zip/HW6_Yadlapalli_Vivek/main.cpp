//
//  main.cpp
//  HW6
//
//  Created by ymmkrishna on 09/10/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include<iostream>
#include<fstream>
#include<string>
#include<iomanip>
#include "func.hpp"

using namespace std;

int main()
{
    
    ifstream infile("SPY1993to2019.txt");
    if(!infile)
    {
        cout<<"Couldn't locate input file";
        exit(1);
    }
    
    int count=0;
    string element;
    while(!infile.eof()) //Finding the count for number of elements in the text file
    {
        infile>>element;
        cout<<"\n "<<element;
        count++;
    }
    infile.close();
    
    ifstream infile2("SPY1993to2019.txt");   //Now computing the values
    
    int rows;
    rows=(count-1)/7;
    cout<<"\n \n \n \n \n";
    cout<<"\nNumber of Elements are "<<count<<"\nNumber of rows are "<<rows-1<<endl;
    rows=rows-1;
    
    
    string *date=new string[rows];double *open=new double[rows];double *high=new double[rows];double *low=new double[rows];double *close=new double[rows];double *adjclose=new double[rows];int *volume=new int[rows];
    

    for(int k=0;k<count-1;k++)         //Reading File into different categories
    {
        infile2>>element;
        if((k+7)%7==0&&k>6)       //For date
        {
            *(date+((k+7)/7)-2)=element;
        }
        else if((k+6)%7==0&&k>6)                 //For open
        {
            *(open+((k+6)/7)-2)=stod(element);
        }
        else if((k+5)%7==0&&k>6)                 //For high
        {
            *(high+((k+5)/7)-2)=stod(element);
        }
        else if((k+4)%7==0&&k>6)                //For low
        {
            *(low+((k+4)/7)-2)=stod(element);
        }
        else if((k+3)%7==0&&k>6)                 //For close
        {
            *(close+((k+3)/7)-2)=stod(element);
        }
        else if((k+2)%7==0&&k>6)                //For adjusted close
        {
            *(adjclose+((k+2)/7)-2)=stod(element);
        }
        else if((k+1)%7==0&&k>6)               //For Volume
        {
            *(volume+((k+2)/7)-2)=stoi(element);
        }
    }
    
    double Adjmax,Adjmin;
    int AdjmaxIndx,AdjminIndx;
    
    MaxMin(adjclose,rows,Adjmax,Adjmin,AdjmaxIndx,AdjminIndx);
    
    cout<<"\n \nThe max adjusted close price is "<<Adjmax<<". \nOn date of : "<<*(date+AdjmaxIndx);
    cout<<"\n \nThe min adjusted close price is "<<Adjmin<<". \nOn date of :"<<*(date+AdjminIndx);
    
    double *AdjDailyReturns=new double[rows-1];
    
    cout<<"\n\n\nGenerating returns \n";
    
    generateReturns(adjclose, rows-1, AdjDailyReturns);
    
    ofstream outfile("Output Data");
    
    double avgRet,retStd;
    char seriesType;
    
    cout<<"\n \nEnter returns type \n'D' or 'd' for daily \n'M' or 'm' for monthly \n'Q' or 'q' for quarterly "<<endl;
    
    cin>>seriesType;
    
    
    AnnualizedStats(AdjDailyReturns,rows,seriesType,avgRet,retStd);
    
    cout<<"\n \nThe average annualized daily returns is : "<<avgRet<<endl;
    cout<<"\n \nThe average annualized volatility is : "<<retStd<<endl;
    
    int Volmax,Volmin;
    int VolmaxIndx,VolminIndx;
    
    MaxMin(volume,rows,Volmax,Volmin,VolmaxIndx,VolminIndx);
    
    cout<<"\n \nThe max Volume is "<<Volmax<<". \nOn date of : "<<*(date+VolmaxIndx);
    cout<<"\n \nThe min Volume is "<<Volmin<<". \nOn date of :"<<*(date+VolminIndx)<<endl;
    
    
    outfile<<"\n \nThe max adjusted close price is "<<Adjmax<<". \nOn date of : "<<*(date+AdjmaxIndx)<<"\n \nThe min adjusted close price is "<<Adjmin<<". \nOn date of :"<<*(date+AdjminIndx)<<" \n \nFor adjusted closing price : \nThe average annualized daily returns is : "<<avgRet<<"\n \nThe average annualized volatility is : "<<retStd<<"\n \nThe max Volume is "<<Volmax<<". \nOn date of : "<<*(date+VolmaxIndx)<<"\n \nThe min Volume is "<<Volmin<<". \nOn date of  :"<<*(date+VolminIndx)<<endl;
}
