//
//  func.cpp
//  HW6
//
//  Created by ymmkrishna on 09/10/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include "func.hpp"
#include<math.h>
#include<iostream>
#include<fstream>
#include<string>
#include<iomanip>
using namespace std;

void MaxMin(double const *arr,const int& n,double& max,double &min,int& maxIndx,int& minIndx)
{
    double a[n];
    for(int k=0;k<n;k++)
    {
        a[k]=*(arr+k);
    }
    sort(a,n);
    max=a[n-1];
    min=a[0];
    for(int k=0;k<n;k++)
    {
        if(*(arr+k)==a[0])
            minIndx=k;
        else if(*(arr+k)==a[n-1])
            maxIndx=k;
    }
}

void swap(double *a,double *b)
{
    double temp;
    temp=*a;
    *a=*b;
    *b=temp;
}

void sort(double a[],int n)
{
    for(int k=0;k<n;k++)
    {
        for(int j=k+1;j<n;j++)
        {
            if(a[k]>a[k])
            {
                double temp1=a[k];double temp2=a[j];
                swap(&temp1,&temp2);
                a[k]=temp1;a[j]=temp2;
            }
        }
    }
}

void generateReturns(double const *prices, const int& n, double *returns)
{
    for(int k=0;k<n;k++)
    {
        *(returns + k)=(*(prices + k+1)-*(prices + k))/(*(prices + k));
    }
}

void MaxMin(int const *arr,const int& n,int& max,int &min,int& maxIndx,int& minIndx)
{
    int a[n];
    for(int k=0;k<n;k++)
    {
        a[k]=*(arr+k);
    }
    sort(a,n);
    max=a[n-1];
    min=a[0];
    for(int k=0;k<n;k++)
    {
        if(*(arr+k)==a[0])
            minIndx=k;
        else if(*(arr+k)==a[n-1])
            maxIndx=k;
    }
}

void swap(int *a,int *b)
{
    int temp;
    temp=*a;
    *a=*b;
    *b=temp;
}

void sort(int a[],int n)
{
    for(int k=0;k<n;k++)
    {
        for(int j=k+1;j<n;j++)
        {
            if(a[k]>a[j])
            {
                int temp1=a[k];int temp2=a[j];
                swap(&temp1,&temp2);
                a[k]=temp1;a[j]=temp2;
            }
        }
    }
}

void AnnualizedStats (double const *returns, const int& n,const char& seriesType,double& avgRet,double & retStd)
{
    double mean=0,xsq=0,sdev=0;
    
    switch(seriesType)
    {
        case 'd' :
        case 'D' :
        {
            for(int k=0;k<n;k++)
            {
                mean=mean+*(returns+k);
                xsq=xsq+((*(returns+k))*(*(returns+k)));
            }
            mean=mean/n;
            sdev=(xsq/n)-(mean*mean);
            avgRet=mean*252;
            retStd=mean*sqrt(252);
            cout<<"\n \nComputed annualizing daily returns";
            break;
        }
        case 'm':
        case 'M':
        {
            for(int k=0;k<n;k++)
            {
                mean=mean+*(returns+k);
                xsq=xsq+((*(returns+k))*(*(returns+k)));
            }
            mean=mean/n;
            sdev=(xsq/n)-(mean*mean);
            avgRet=mean*12;
            retStd=mean*sqrt(12);
            cout<<"\n \nComputed annualizing monthly returns";
            break;
        }
        case 'q':
        case 'Q':
        {
            for(int k=0;k<n;k++)
            {
                mean=mean+*(returns+k);
                xsq=xsq+((*(returns+k))*(*(returns+k)));
            }
            mean=mean/n;
            sdev=(xsq/n)-(mean*mean);
            avgRet=mean*4;
            retStd=mean*sqrt(4);
            cout<<"\n \nComputed annualizing quarterly returns";
            break;
        }
        default :
            cout<<"\n \nIncorrect Input";
    }
    
}
