//
//  main.cpp
//  HW4_Q2
//
//  Created by ymmkrishna on 21/09/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include <iostream>
#include <cmath>
using namespace std;

int main(int argc, const char * argv[]) {
    
    float num1 =0.0;
    int num2;
    int count=0;
    char reply;
    bool i=true;
    while(i){
        cout <<"Do you want to play (Y/N): "<<endl;
        cin >> reply;
        cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');//clearing buffer
        
        switch(reply){
            case 'Y':
            case 'y':{
                cout <<"Enter a positive integer: "<<endl;
                cin >> num1;
                cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n'); //clearing buffer
                while ( !cin ||num1<=0 || !(floor(num1) == ceil(num1))) //catching invalid inouts
                {
                    cin.clear ();
                    cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');//clearing buffer
                    cout << "I said enter a +ve integer. Try again: ";
                    cin >> num1;
                }
                num2=num1;
                while(num2>1){
                    if(num2 % 2==0){
                        num2 = num2/2;
                    }else{
                        num2 = num2*3+1;
                    }
                    count++;
                }
                cout<<"it took "<<count<<" steps to reduce "<<num1<<" to 1"<<endl;
                i=false;
                break;
            }
            case 'N':
            case 'n':{
                i=false;
                break;
            }
            default :{
                cout << "Invalid Input. Try again" << endl;
                
            
            }
            }
        
    }
    return 0;
    
}
