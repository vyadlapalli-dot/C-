//
//  main.cpp
//  HW4_Q3
//
//  Created by ymmkrishna on 21/09/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include <iostream>
#include <fstream>
#include<cmath>
#include "move_rings.hpp"

using namespace std;

int main() {
    
        float num1;
        int num2;
        cout<<"How many rings in stack A(+ve integer): "<<endl;
        cin >> num1;
        cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n'); //clearing buffer
        while ( !cin ||num1<=0 || !(floor(num1) == ceil(num1))) //catching invalid inouts
        {
            cin.clear ();
            cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');//clearing buffer
            cout << "I said enter a +ve integer. Try again: ";
            cin >> num1;
        }
        num2=num1;
    
        move_rings(num2, 'A', 'C', 'B'); // A, B and C are names of stacks
        return 0;
   
}
