//
//  move_rings.cpp
//  HW4_Q3
//
//  Created by ymmkrishna on 21/09/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//
#include <iostream>

#include "move_rings.hpp"

using namespace std;

void move_rings(int n, char from,
                  char to, char spare)
{
    if (n == 1)
    {
        cout << "Move ring 1 from stack " << from <<
        " to stack " << to<<endl;
        return;
    }
    move_rings(n - 1, from, spare, to);
    cout << "Move disk " << n << " from stack " << from <<
    " to stack " << to << endl;
    move_rings(n - 1, spare, to, from);
} 
