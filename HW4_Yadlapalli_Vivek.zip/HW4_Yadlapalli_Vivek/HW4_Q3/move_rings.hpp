//
//  move_rings.hpp
//  HW4_Q3
//
//  Created by ymmkrishna on 21/09/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//
#include <iostream>
#ifndef move_rings_hpp
#define move_rings_hpp

#include <stdio.h>
using namespace std;

void move_rings(int n, char from_rod,
                char to_rod, char aux_rod);


#endif /* move_rings_hpp */
