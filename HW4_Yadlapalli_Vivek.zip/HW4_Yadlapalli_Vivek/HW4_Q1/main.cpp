//
//  main.cpp
//  HW4
//
//  Created by ymmkrishna on 21/09/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include <iostream>
#include <cmath>
#include "Function.hpp"

using namespace std;


int main() {
    float num1,num2;
    
    cout <<"Enter integer to find the sum of digits: "<<endl;
    cin >> num1;
    cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
    if(num1<0){
        num1=-num1;
    }
    while ( !cin|| !(floor(num1) == ceil(num1))) //catching invalid inouts
    {
        cin.clear ();
        cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
        cout << "I said enter an integer. Try again: ";
        cin >> num1;
        cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
        if(num1<0){
            num1=-num1;
        }
    }
    
    cout << "Sum of digits in "<<num1<<" is "<<sum_of_digits(num1)<<"\n\n"<<endl;
    
    cout <<"Enter +ve int to find approximation of golden mean ratio: "<<endl;
    cin >>num2;
    cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
    while ( !cin || num2<0 || !(floor(num2) == ceil(num2)))
    {
        cin.clear ();
        cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
        cout << "I said enter a +ve integer. Try again: ";
        cin >> num2;
        cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
    }
    

    cout<<"Golden mean ratio aprroximation("<<num2<<") is "<<golden_mean_ratio(num2)<<"\n\n"<<endl;
    
    
    return 0;
}


