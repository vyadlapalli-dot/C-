//
//  Function.hpp
//  HW4
//
//  Created by ymmkrishna on 21/09/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#ifndef Function_hpp
#define Function_hpp

#include <stdio.h>

using namespace std;

int sum_of_digits(int num);

float golden_mean_ratio(float num);


#endif /* Function_hpp */
