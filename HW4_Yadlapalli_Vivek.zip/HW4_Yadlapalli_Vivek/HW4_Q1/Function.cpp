//
//  Function.cpp
//  HW4
//
//  Created by ymmkrishna on 21/09/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//
#include "Function.hpp"
using namespace std;

int sum_of_digits(int num) {
    static int sum=0;
    if(num!=0){
        sum = sum + num % 10;
        num = num/10;
        sum_of_digits(num);
    }
    return sum;
}

float golden_mean_ratio(float num){
    static int count=num;
    static float sum=num;
    if(count!=0){
        sum = 1/(1+sum);
        --count;
        golden_mean_ratio(sum);
    }
    return sum;
}


