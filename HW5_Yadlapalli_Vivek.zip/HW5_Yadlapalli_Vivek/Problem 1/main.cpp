//
//  main.cpp
//  Home_Work_5_A
//
//  Created by ymmkrishna on 02/10/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include <iostream>
#include<fstream>
#include<string.h>
#include<stdlib.h>
#include "functions.hpp"

using namespace std;

int main()
{
    
    ifstream infile("dataChar");
    if(!infile)
    {
        cout<<"can't open input file "<<endl;
        exit(1);
    }
    char a[19];
    for(int i=1;i<=19;i++)
    {
        infile>>a[i-1];
    }
    ofstream outfile("output.dat");
    
    
    
    mysort(a,19);
    
    outfile<<"\n Sorted character array is \n";
    for(int k=1;k<=19;k++)
    {
        outfile<<a[k-1]<<" ";
    }
    
    
    
    ifstream infile2("dataString");
    if(!infile)
    {
        cout<<"can't open input file "<<endl;
        exit(1);
    }
    string str[30];
    for(int k=1;k<31;k++)
    {
        infile2>>str[k-1];
    }
    
    mysort(str,30);
    
    outfile<<"\n Sorted string array is \n";
    for(int k=1;k<31;k++)
    {
        outfile<<str[k-1]<<" ";
    }
    
    
    
    
    ifstream infile3("dataDouble");
    if(!infile)
    {
        cout<<"can't open input file "<<endl;
        exit(1);
    }
    string d[53];
    for(int k=1;k<54;k++)
    {
        infile3>>d[k-1];
    }
    
    
    mysort(d,53);
    
    outfile<<"\n Sorted double array is \n";
    for(int k=1;k<54;k++)
    {
        outfile<<d[k-1]<<" ";
    }
    
    outfile.close();
    return 0;
}


