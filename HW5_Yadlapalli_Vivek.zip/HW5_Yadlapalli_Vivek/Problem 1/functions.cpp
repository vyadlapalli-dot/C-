//
//  functions.cpp
//  Home_Work_5
//
//  Created by ymmkrishna on 02/10/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//
#include <iostream>
#include<fstream>
#include<string.h>
#include<stdlib.h>
#include "functions.hpp"
using namespace std;

void myswap(double *a,double *b)
{
    double temp;
    temp=*a;
    *a=*b;
    *b=temp;
}

void myswap(char *a,char *b)
{
    char temp;
    temp=*a;
    *a=*b;
    *b=temp;
}


void myswap(string *a,string *b)
{
    string temp;
    temp=*a;
    *a=*b;
    *b=temp;
}

void mysort(double a[],int n)
{
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(a[i]>a[j])
            {
                double temp1=a[i];double temp2=a[j];
                myswap(&temp1,&temp2);
                a[i]=temp1;a[j]=temp2;
            }
        }
    }
    cout<<"\n Post sorting: \n";
    for(int i=0;i<n;i++)
    {
        cout<<a[i]<<endl;
    }
}


void mysort(char a[],int n)
{
    for(int i=0;i<=n;i++)
    {
        for(int j=i+1;j<=n;j++)
        {
            if(a[i]>a[j])
            {
                char temp1=a[i];char temp2=a[j];
                myswap(&temp1,&temp2);
                a[i]=temp1;a[j]=temp2;
            }
        }
    }
    cout<<"\n Post sorting: \n";
    for(int i=0;i<n;i++)
    {
        cout<<a[i]<<endl;
    }
}

void mysort(string a[],int n)
{
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(a[i]>a[j])
            {
                string temp1=a[i];string temp2=a[j];
                myswap(&temp1,&temp2);
                a[i]=temp1;a[j]=temp2;
            }
        }
    }
    cout<<"\n Post sorting: \n";
    for(int i=0;i<n;i++)
    {
        cout<<a[i]<<endl;
    }
}








