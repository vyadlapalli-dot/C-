//
//  functions.hpp
//  Home_Work_5
//
//  Created by ymmkrishna on 02/10/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#ifndef functions_hpp
#define functions_hpp
#include<fstream>
#include<string.h>
#include<stdlib.h>
#include <stdio.h>

using namespace std;


void myswap(double *a,double *b);
void myswap(char *a,char *b);
void myswap(string *a,string *b);

void mysort(double a[],int n);
void mysort(char a[],int n);
void mysort(string a[],int n);

#endif /* functions_hpp */
