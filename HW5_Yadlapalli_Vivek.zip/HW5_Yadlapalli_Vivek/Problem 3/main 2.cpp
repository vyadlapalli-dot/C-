//
//  main.cpp
//  HW5_Prob2
//
//  Created by ymmkrishna on 02/10/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//
#include<iostream>
#include<math.h>
#include<cmath>
#include<array>
#include<fstream>
#define EPSILON 0.0001
using namespace std;
bool i=true;


double func1(double x)
{
    return 4*x*x - 8*x - 5;
}
double func2(double x)
{
    return exp(-pow(x, 2)) - x;
}
double func3(double x)
{
    return log(2*x/3.14)+sin(x);
}

double derivFunc1(double x)
{
    return 8*x - 8;
}

double derivFunc2(double x)
{
    return exp(-pow(x, 2))*x*(-2) -1;
}
double derivFunc3(double x)
{
    return (1/x) + cos(x);
}

void newtonRaphson(double x,int f)
{   double h;
    switch(f){
        case 1:
            h = func1(x) / derivFunc1(x);
            while (abs(h) >= EPSILON)
            {
                h = func1(x)/derivFunc1(x);
                
                x = x - h;
            }
        
            cout << "The value of the root is : " << x<<endl;
            break;
        case 2:
            h = func2(x) / derivFunc2(x);
            while (abs(h) >= EPSILON)
            {
                h = func2(x)/derivFunc2(x);
                
                x = x - h;
            }
        
            cout << "The value of the root is : " << x<<endl;
            break;
        case 3:
            h = func3(x) / derivFunc3(x);
            while (abs(h) >= EPSILON)
            {
                h = func3(x)/derivFunc3(x);
                
                x = x - h;
            }
        
            cout << "The value of the root is : " << x<<endl;
        default:
            i=false;
            
        
        
}
    
}

int main()
{
    while(i){
    double x0;
    int f;
    cout<<"Enter function number"<<endl;
    cin>>f;
    cout<<"Enter x0 value"<<endl;
    cin>>x0;
    newtonRaphson(x0,f);
    return 0;
    }
}
