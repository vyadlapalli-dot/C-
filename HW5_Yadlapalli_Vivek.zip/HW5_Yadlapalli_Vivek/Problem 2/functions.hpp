//
//  functions.hpp
//  HW5
//
//  Created by ymmkrishna on 02/10/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//
#include<iostream>
#include<math.h>
#include<cmath>
#include<array>
#include<fstream>
#ifndef functions_hpp
#define functions_hpp

using namespace std;

void addVectors(double v1[],double v2[], double v3[],int size);
double lenVector(double vec[],int size);
double dotPVectors(double a[],double b[],int size, double *p);

#include <stdio.h>

#endif /* functions_hpp */
