//
//  main.cpp
//  HW5
//
//  Created by ymmkrishna on 02/10/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include<iostream>
#include<math.h>
#include<cmath>
#include<array>
#include<fstream>
#include "functions.hpp"

using namespace std;


int main()
{
    ifstream infile("dataVector");
    if(!infile)
    {
        cout<<"can't open input file "<<endl;
        exit(1);
    }
    double read_vector[16];
    for(int k=0;k<16;k++)
    {
        infile>>read_vector[k];
    }
    
    
    ofstream outfile("newoutput.dat");
    if(!outfile)
    {
        cout<<"can't open output file "<<endl;
        exit(2);
    }
    outfile<<"The following were read"<<endl;
    for(int k=0;k<16;k++)
    {
        outfile<<read_vector[k]<<" ";
    }
    
    
    double matrix[4][4];
    for(int i=0;i<4;i++)
    {
        for(int j=0;j<4;j++)
        {
            matrix[i][j]=read_vector[j+(i*4)];
        }
        
    }
    
    
    double tv[4]={0,0,0,0},ans[4]={0,0,0,0};
    for(int i=0;i<4;i++)
    {
        for(int j=0;j<4;j++)
        {
            tv[j]=matrix[i][j];
        }
        addVectors(tv,ans,ans,4);
    }
    
    cout<<"Sum of the four row vectors is a new vector: \n";
    for(int i=0;i<4;i++)
    {
        cout<<ans[i]<<" ";
    }
    
    outfile<<"\n\n Sum of all four row vectors is a new vector \n";
    for(int i=0;i<4;i++)
    {
        outfile<<ans[i]<<" ";
    }
    
    
    
    outfile<<"\n \n"<<"Length of the rows \n";
    
    for(int i=0;i<4;i++)
    {
        for(int j=0;j<4;j++)
        {
            tv[j]=matrix[i][j];
        }
        outfile<<"Length of row "<<i<<" is "<<lenVector(tv,4)<<endl;
    }
    
    
    
    
    
    double v1[4]={0,0,0,0};
    double v2[4]={0,0,0,0};
    double angle[4][4];
    
    for(int i=0;i<4;i++)
        for(int j=0;j<4;j++)
            angle[i][j]=0;
    
    int size=4;
    
    double dotprd[4][4];
    
    for(int i=0;i<4;i++)
        for(int j=0;j<4;j++)
            dotprd[i][j]=0;
    
    
    for(int k=0;k<4;k++)
    {
        for(int i=3;i>k;i--)
        {
            for(int j=0;j<4;j++)
            {
                v1[j]=matrix[k][j];
                v2[j]=matrix[i][j];
            }
            
            dotprd[k][i] = dotPVectors(v1,v2,size,&angle[k][i]);
            cout<<"\n Dot product of row "<<k<<" and row "<<i<<" is "<<dotprd[k][i];
            cout<<"\n Angle between them is "<<angle[k][i]<<endl;
            
        }
    }
    
    
    for(int k=0;k<4;k++)
    {
        for(int i=k+1;i<4;i++)
        {
            
            outfile<<"\n"<<"Dot product of row "<<k+1<<" and row "<<i+1<<" is "<<dotprd[k][i]<<"\n The angle between them is "<<angle[k][i]<<"\n\n";
            
        }
    }
    
    outfile.close();
    
}
