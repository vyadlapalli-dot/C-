//
//  functions.cpp
//  HW5
//
//  Created by ymmkrishna on 02/10/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//
#include<iostream>
#include<math.h>
#include<cmath>
#include<array>
#include<fstream>
#include "functions.hpp"

using namespace std;

void addVectors(double v1[],double v2[], double v3[],int size)
{
    
    for(int k=0;k<size;k++)
    {
        v3[k]=v1[k]+v2[k];
    }
    
}

double lenVector(double vec[],int size)
{
    int ans=0;
    for(int i=0;i<size;i++)
    {
        ans=ans+(vec[i]*vec[i]);
    }
    return sqrt(ans);
}

double dotPVectors(double a[],double b[],int size, double *p)
{
    double product=0;
    for(int i=0;i<4;i++)
        
        for(int i=1;i<size;i++)
        {
            product=product+(a[i]*b[i]);
        }
    
    double angle=(product)/(lenVector(a,4)*lenVector(b,4));
    *p=angle;
    
    return product;
}
