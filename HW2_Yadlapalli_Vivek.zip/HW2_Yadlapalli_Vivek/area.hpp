//
//  area.hpp
//  HW2
//
//  Created by ymmkrishna on 11/09/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#define area_hpp

#include <stdio.h>


float area(float r);
float area(double e);
float area(int r);
float area(float l,float w);
float area(float a, float b,float w);
