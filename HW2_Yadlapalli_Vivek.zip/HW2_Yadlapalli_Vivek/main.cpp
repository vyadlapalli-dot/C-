//
//  main.cpp
//  HW2
//
//  Created by ymmkrishna on 10/09/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include <iostream>
#include <string>
#include <math.h>
#include "area.hpp"
#include "volume.hpp"

using namespace std;



int main() {
    
    float radius,length,width,side1,side2,angle,height;
    double edge;
    int rad;
    
    cout << "Enter Radius of the circle: "<<endl;
    cin >> radius ;
    
    cout << "The area of the circle is "<<area(radius)<<endl;
    
    //cout << "Enter the edge length of the cube: "<<endl;
    //cin >> edge;
    
    //cout <<"The surface area of the cube is "<<surface_area_cube(edge)<<endl;
    
    cout << "Enter the radius of the sphere: "<<endl;
    cin >> rad;
    
    cout <<"The surface area of the sphere is "<<area(rad)<<endl;
    
    cout << "Enter the length of the rectangle: "<<endl;
    cin >> length;
    
    cout << "Enter the width of the rectangle: "<<endl;
    cin >> width;
    
    cout <<"The area of the rectangle is "<<area(length,width)<<endl;
    
    cout << "Enter the first side of the triangle: "<<endl;
    cin >> side1;
    
    cout << "Enter the second side of the triangle: "<<endl;
    cin >> side2;
    
    cout << "Enter the angle between the sides: "<<endl;
    cin >> angle;
    
    cout <<"The area of the triangle is "<<area(side1,side2,angle)<<endl;
    
    cout << "Enter the radius of the sphere: "<<endl;
    cin >> radius;
    
    cout <<"The volume of the sphere is "<<volume(radius)<<endl;
    
    cout << "Enter the edge length of the cube: "<<endl;
    cin >> edge;
    
    cout <<"The volume of the cube is "<<volume(edge)<<endl;
    
    cout << "Enter the radius of the cylinder: "<<endl;
    cin >> radius;
    
    cout << "Enter the length of the cylinder: "<<endl;
    cin >> length;
    
    cout <<"The volume of the cylinder is "<<volume(radius, length)<<endl;
    
    cout << "Enter the width of the rectanglur prism: "<<endl;
    cin >> width;
    
    cout << "Enter the length of the rectanglur prism: "<<endl;
    cin >> length;
    
    cout << "Enter the height of the rectanglur prism: "<<endl;
    cin >> height;
    
    cout <<"The volume of rectangular prism is "<<volume(width,length,height)<<endl;
    
    }




