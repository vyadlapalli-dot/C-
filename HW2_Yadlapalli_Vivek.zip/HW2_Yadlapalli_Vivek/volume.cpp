//
//  volume.cpp
//  HW2
//
//  Created by ymmkrishna on 11/09/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include "volume.hpp"
#include<math.h>

float volume(float r){                      // r is the radius of the sphere
    return 4*M_PI*pow(r,3)/3;
}
float volume(double e){                        // e is the edge length of the cube
    return pow(e,3);
}
float volume(float r, float l){        //r is the radius of cylinder and l is the length of the cylinder
    return M_PI*pow(r,3)*l;
}
float volume(float w,float l, float h){//w is width, l is length and h is the height of the prism
    return w*l*h;
}


