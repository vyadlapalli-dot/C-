//
//  area.cpp
//  HW2
//
//  Created by ymmkrishna on 11/09/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//
#include<math.h>
#include "area.hpp"

float area(float r){                         //r is the radius of the circle
    return M_PI*pow(r,2);
}
float area(double e){                   //e is the edge of the cube
    return 6*pow(e,2);
}
float area(int r){                 //r is the radius of the sphere
    return 4*M_PI*pow(r,2);
}
float area(float l,float w){              //l and w are sides of a rectangle
    return l*w;
}
float area(float a, float b,float w){     //a and b are sides, while w is the angle in degrees
    return 0.5*a*b*sin(w);
}
