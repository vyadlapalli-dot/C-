//
//  volume.hpp
//  HW2
//
//  Created by ymmkrishna on 11/09/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//


#define volume_hpp

#include <stdio.h>

float volume(float r);
float volume(double e);
float volume(float r, float l);
float volume(float w,float l, float h);
