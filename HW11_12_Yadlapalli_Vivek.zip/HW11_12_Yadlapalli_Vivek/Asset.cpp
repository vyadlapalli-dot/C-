//
//  Asset.cpp
//  HW_11
//
//  Created by ymmkrishna on 07/12/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include "Asset.hpp"

using namespace std;

Asset:: Asset(const Asset& x) {
    assetType = x.assetType;
    currentPrice = x.currentPrice;
    nPrices = x.nPrices;
    securityIssuer = x.securityIssuer;
    securitySymbol = x.securitySymbol;
    delete pHist;
    if(x.pHist != nullptr){
        pHist = new double;
        *pHist = *(x.pHist);
    }
}

Asset& Asset:: operator=(const Asset& x) {
if(&x != this) {
    assetType = x.assetType;
    currentPrice = x.currentPrice;
    nPrices = x.nPrices;
    securityIssuer = x.securityIssuer;
    securitySymbol = x.securitySymbol;
    
    delete pHist; //free memory before pointing away
    if(x.pHist != nullptr){
        pHist = new double;
        *pHist = *(x.pHist);
    }
}
return *this;
}

Asset::Asset(Asset&& src) : assetType{src.assetType}, currentPrice{src.currentPrice},nPrices{src.nPrices},securityIssuer{src.securityIssuer},securitySymbol{src.securitySymbol},pHist{src.pHist}
{
src.pHist = nullptr;
}

Asset& Asset:: operator=(Asset&& src)
{
if(this != &src){
    assetType = src.assetType;
    currentPrice = src.currentPrice;
    nPrices = src.nPrices;
    securityIssuer = src.securityIssuer;
    securitySymbol = src.securitySymbol;
    delete []pHist;
    pHist = src.pHist;
    src.pHist = nullptr;
}
return *this;
}

Asset:: ~Asset(){
//This will delete the array itself, not just the pointer
if(pHist != nullptr) delete [] pHist;
}


