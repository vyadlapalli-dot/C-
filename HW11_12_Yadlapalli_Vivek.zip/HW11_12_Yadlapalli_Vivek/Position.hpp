//
//  Position.hpp
//  HW_11
//
//  Created by ymmkrishna on 07/12/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#ifndef Position_hpp
#define Position_hpp

#include <stdio.h>
#include <math.h>
#include "Asset.hpp"
class Position{
private:
    Asset* a;
    int size;
    double costUnit;
    double age;
public:
    Position(){}
    Position(Asset* a, int size, double costUnit, double age):
    a{a}, size{size}, costUnit{costUnit}, age{age}{}
    
    //setters
    void setPointerToAsset (Asset *p){
        a = p;
    }
    void setSize (const int& x) { size=x; }
    void setCostUnit (const double& x) { costUnit = x;}
    void setAge (const double& x) { age = x;}

    //getters
    Asset* getAssetPointer() {return a;}
    const int& getSize() const { return size ; }
    const double& getCostUnit () const { return costUnit; }
    const double& getAge () const { return age; }
    
    const double getCurrentMarketValue() const {
        return a->getMarketValue(size);
    }
    
    const double getTotalDollarCostBasis() const {
        return a->getMarketValue(costUnit,size);
    }
    
    const double getAnnualizedReturn() const{
        return (pow((a->getcurrentPrice()/costUnit),(1/age))-1);
    }
    friend ostream& operator<< (ostream &os,const Position&p);
};



#endif /* Position_hpp */
