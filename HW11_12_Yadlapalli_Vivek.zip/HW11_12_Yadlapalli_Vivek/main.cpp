//
//  main.cpp
//  HW_11
//
//  Created by ymmkrishna on 07/12/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include <stdio.h>
#include<iostream>
#include<fstream>
#include<cstring>
#include<string.h>
#include<math.h>

#include "Asset.hpp"

#include "Position.hpp"

using namespace std;



int main()

{

    cout<<"\n Main";

    ofstream outfile("output.dat");
    
    string SecSym[11];

    Asset *ptrs[11];
    

    cout<<"\n Input: Equity Data.....";

    ifstream infile("equityData.txt");

    string SS,AT,SI;

    if(!infile)

    {
        cout<<"\n Equity Data not found ";
        exit(1);

    }

    Equity E[4];

    

    for(int i = 0 ; i <= 4; i ++)

    {

        infile >> SS;

        infile >> AT;

        infile >> SI;

        if(i!=0)

        {

            Equity TE("EQUITY",SI,SS);

            E[i-1] = TE;

            SecSym[i-1]=SS;

            ptrs[i-1]=&E[i-1];

        }

    }

    for(int i = 0 ; i <= 3 ; i++)

    {
        outfile<<E[i];
    }

    infile.close();

    outfile<<endl<<endl<<endl;

    cout<<"\n\n Input: Bond Data.....";

    ifstream infile2("bondData.txt");

    if(!infile2){
        cout<<"\n Bond Data not found ";

        exit(2);
    }

    Bond B[3];

    string st_CR,st_freq,st_parVal;

    double CR = 0,freq = 0,parVal = 0;

    for(int i = 0 ; i <= 3; i ++)

    {

        infile2 >> SS;

        infile2 >> AT;

        infile2 >> SI;

        infile2 >> st_CR;

        infile2 >> st_freq;

        infile2 >> st_parVal;

        if(i!=0)

        {

            CR = stod(st_CR);

            freq = stod(st_freq);

            parVal = stod(st_parVal);

            Bond TB(SI,SS,CR,freq,parVal);

            B[i-1] = TB;

            SecSym[i-1+4]=SS;

            ptrs[i-1+4]=&B[i-1];

        }

    }


    for(int i = 0 ; i <= 2 ; i++){
        outfile<<B[i];
    }

    infile2.close();

    outfile<<endl<<endl<<endl;

    cout<<"\n\n Input: Preferred Data.....";

    ifstream infile3("pfdData.txt");

    if(!infile3)

    {

        cout<<"\n Preferred Data not found ";

        exit(3);

    }
    
    Preferred P[4];

    string st_dvd,st_Freq,st_fVal;

    double dvd = 0,Freq = 0,fVal = 0;

    for(int i = 0 ; i <= 4; i ++){

        infile3 >> SS;

        infile3 >> AT;

        infile3 >> SI;

        infile3 >> st_dvd;

        infile3 >> st_Freq;

        infile3 >> st_fVal;

        if(i!=0){
            dvd = stod(st_dvd);

            Freq = stod(st_Freq);

            fVal = stod(st_fVal);

            Preferred TP(SI,SS,dvd,Freq,fVal);

            P[i-1] = TP;

            SecSym[i-1+7]=SS;

            ptrs[i-1+7]=&P[i-1];

        }

    }

   for(int i = 0 ; i <= 3 ; i++){
        outfile<<P[i];
       
   }

    infile3.close();

    outfile<<endl<<endl<<endl;
    
    cout<<"\n\n Input: Portfolio Data.....";

    ifstream infile4("port_data.txt");

    if(!infile4){
        cout<<"\n Protfolio Data not found ";
        exit(4);
    }

    Position Port[11];

    string st_MktPx,st_Cost,st_Age,st_PosSize;

    for(int i = 0;i <= 11; i++){

        infile4>>SS;

        infile4>>AT;

        infile4>>SI;

        infile4>>st_MktPx;

        infile4>>st_Cost;

        infile4>>st_Age;

        infile4>>st_PosSize;

        int SymIndex = 0;

        for(int j = 0; j <= 10; j++)

            if(SecSym[j]==SS){
                SymIndex = j;
            }

        if(i!=0){

            Port[i-1].setPointerToAsset(ptrs[SymIndex]);

            Port[i-1].getAssetPointer()->setcurrentPrice(stod(st_MktPx));

            Port[i-1].setSize(stoi(st_PosSize));

            Port[i-1].setCostUnit(stod(st_Cost));

            Port[i-1].setAge(stod(st_Age));

        }

    }

    

    

    outfile<<"\n\n Printing Potfolio Data..... \n\n";

    
    

    for(int i=0;i<11;i++)

    {

         outfile<<"\nSecurity Symbol: "<<Port[i].getAssetPointer()->getsecuritySymbol()<<"\nAsset Type: "<<Port[i].getAssetPointer()->getassetType()<<"\nSecurity Issuer: "<<Port[i].getAssetPointer()->getsecurityIssuer()<<"\nCurrent Price: "<<Port[i].getAssetPointer()->getcurrentPrice()<<"\nCost Basis: "<<Port[i].getCostUnit()<<"\nAge: "<<Port[i].getAge()<<"\nPosition Size: "<<Port[i].getSize()<<endl;

    }

    double portReturn =0;

    double portValue = 0;

    for(int i=0;i<11;i++)

    {
        portReturn=portReturn+((Port[i].getAnnualizedReturn())*(Port[i].getCurrentMarketValue()));
        portValue = portValue + Port[i].getCurrentMarketValue();

    }

    

    portReturn=portReturn/portValue;

    

    outfile<<endl<<endl<<endl;

    

    cout<<endl<<endl<<"Market Value Weighted Annualized Portfolio Return is "<<portReturn<<endl;

    

    outfile<<endl<<endl<<"Market Value Weighted Annualized Portfolio Return is "<<portReturn<<"("<<portReturn*100<<"%)";

    

    

    

}

