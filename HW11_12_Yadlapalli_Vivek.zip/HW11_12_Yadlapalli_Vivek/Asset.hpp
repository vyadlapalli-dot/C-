//
//  Asset.hpp
//  HW_11
//
//  Created by ymmkrishna on 07/12/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#ifndef Asset_hpp
#define Asset_hpp

#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class Asset{
private:
    string assetType;
    double currentPrice;
    string securityIssuer;
    string securitySymbol;
    double *pHist;
    int nPrices;
public:
    Asset(){};
    Asset(string a): assetType{a},currentPrice{},securityIssuer{},securitySymbol{},pHist{nullptr},nPrices{}{}
    Asset(string a,string b, string c): assetType{a},currentPrice{},securityIssuer{b},securitySymbol{c},pHist{nullptr},nPrices{}{}
    Asset(string a,string b, string c,double*p,int n): assetType{a},currentPrice{},securityIssuer{b},securitySymbol{c},pHist{p},nPrices{n}{}
    Asset(const Asset&);
    Asset& operator=(const Asset&);
    Asset(Asset&&);
    Asset& operator=(Asset&&);
    
    //setters
    void setcurrentPrice (const double& x) { currentPrice=x; }
    void setPrices (const double *p,const int& x) {
        nPrices=x;
        pHist = new double;
        for(int i=0;i<x;++i){
            pHist[i] = p[i];
        }
        
    }
    //getters
    virtual const string& getassetType() const { return assetType; }
    const double& getcurrentPrice () const { return currentPrice; }
    const string& getsecurityIssuer () const { return securityIssuer; }
    const string& getsecuritySymbol () const { return securitySymbol; }
    
    virtual double getMarketValue(const int& n){
        return n*currentPrice;
    };
    virtual double getMarketValue(const double& price, const int& n){
        return n * price;
    };
    
    //destructor
    virtual ~Asset();
    
};

class Equity: public Asset {
public:
    Equity(){};
    Equity(string a): Asset("EQUITY"){};
    Equity(string a,string b, string c): Asset(a,b,c){};
    Equity(string a,string b, string c,double*p,int n): Asset(a,b,c,p,n){};
    virtual double getMarketValue(const int& n){
        return n*getcurrentPrice();
    }
    virtual double getMarketValue(const double& price, const int& n){
        return n * price;
    };
    friend ostream& operator<< (ostream &os,const Equity&p);
protected:
    virtual void print(ostream& o) const{
        o << "(" << getassetType() << "," << getsecurityIssuer() << "," << getsecuritySymbol() <<")";
    }
};

inline ostream& operator<< (ostream &os,const Equity&p){
    p.print(os);
    return os;
}

class Preferred: public Equity {
private:
    double dividendPerPayment;
    double dividendPaymentFrequency;
    double faceValue;
public:
    Preferred(): Equity("PFD"){};
    Preferred(string b, string c,double a,double d, double e): Equity("PFD",b,c),dividendPerPayment{a},dividendPaymentFrequency{d},faceValue{e}{}
    Preferred(string b, string c,double*p,int n): Equity("PFD",b,c,p,n){}
protected:
    virtual void print(ostream& o) const{
        o << "(" << getassetType() << "," << getsecurityIssuer() << "," << getsecuritySymbol() <<","<< dividendPerPayment << "," << faceValue << ")";
    }
};
class Bond: public Equity {
private:
    double couponRate;
    double couponPaymentFrequency;
    double parValue;
public:
    Bond(): Equity("BOND"){};
    Bond(string b, string c,double a,double d, double e): Equity("BOND",b,c), couponRate{a},couponPaymentFrequency{d},parValue{e}{}
    Bond(string b, string c,double*p,int n): Equity("BOND",b,c,p,n){}
    virtual double getMarketValue(const int& n){
        return n*getcurrentPrice();
    }
    virtual double getMarketValue(const double& price, const int& n){
        return n * price;
    }
protected:
    virtual void print(ostream& o) const{
        o << "(" << getassetType() << "," << getsecurityIssuer() << "," << getsecuritySymbol() <<","<< couponRate << "," << parValue << ")";
    }
};


#endif /* Asset_hpp */
