//
//  PositionManager.cpp
//  HW_11
//
//  Created by ymmkrishna on 07/12/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include <stdio.h>
