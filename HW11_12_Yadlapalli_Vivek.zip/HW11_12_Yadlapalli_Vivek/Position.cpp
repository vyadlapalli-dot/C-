//
//  Position.cpp
//  HW_11
//
//  Created by ymmkrishna on 07/12/19.
//  Copyright © 2019 ymmkrishna. All rights reserved.
//

#include "Position.hpp"


ostream& operator<< (ostream &os,const Position&p){
    os<<"("<<p.a->getassetType()<<","<<p.a->getsecuritySymbol()<<","<<p.getCurrentMarketValue()<<","<<p.getAnnualizedReturn()<<")";
    return os;
}
